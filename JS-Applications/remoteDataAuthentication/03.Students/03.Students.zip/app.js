window.addEventListener('load', onLoad);

//Table data
const tBody = document.querySelector('tbody');
const url = 'http://localhost:3030/jsonstore/collections/students';

//SubmitForm data
const form = document.querySelector('form');
form.addEventListener('submit', onDefault);

async function onDefault(e) {
    e.preventDefault();
    const data = new FormData(form);

    let postObj = {};
    for (let [key, value] of data.entries()) {
        if (key === 'firstName' || key === 'lastName') {
            if (value.trim() === '') {
                return;
            }
        } else if (key === 'facultyNumber') {
            if (value.trim() === '' || !/^\d+$/.test(value)) {
                return;
            }
        } else if (key === 'grade') {
            if (value.trim() === '' || isNaN(Number(value))) {
                return;
            }
        }

        if (key == 'facultyNumber' || key == 'grade') {
            value = Number(value);
        }
        postObj[key] = value;
    }

    try {
        let request = await fetch(url, {
            method: 'post',
            headers: { 'Content-type': 'applications/json' },
            body: JSON.stringify(postObj)
        });

        if (!request.ok) {
            const error = await request.json();
            throw error;
        }
    } catch (err) {
        alert(err.message)
    }

    onLoad();
}

async function onLoad(e) {
    tBody.innerHTML = '';

    try {
        let response = await fetch(url);

        if (!response.ok) {
            const error = await response.json();
            throw error
        };
        const data = await response.json();

        Object.values(data).forEach(x => {
            let tr = document.createElement('tr');
            let td1 = document.createElement('td');
            td1.textContent = x.firstName
            let td2 = document.createElement('td');
            td2.textContent = x.lastName
            let td3 = document.createElement('td');
            td3.textContent = x.facultyNumber;
            let td4 = document.createElement('td');
            td4.textContent = x.grade;
            tr.appendChild(td1);
            tr.appendChild(td2);
            tr.appendChild(td3);
            tr.appendChild(td4);
            tBody.appendChild(tr);
        })
    } catch (err) {
        alert(err.message);
    }
}